#!/bin/bash

cp ConfAllezCiao/.bash_aliases ~/

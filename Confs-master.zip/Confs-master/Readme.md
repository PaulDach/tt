

Pour utiliser Les confs faire -> ./ConfSetup.sh nomduscript
Pour supprimer la conf faire -> ./ResetConf/reset.sh nomduscript

ne vous inquietez pas les etudiants n'ont aucun moyen de recuperer le repo de conf. (Sauf si il connaissent mon github lol)(et qu'il savent clone lol)
Ni de voir une trace de votre passage (Juste des petits truc sont mis dans un dossier +/- cache pour eux.)
-Pas d'historique dispo donc pas de soucis
